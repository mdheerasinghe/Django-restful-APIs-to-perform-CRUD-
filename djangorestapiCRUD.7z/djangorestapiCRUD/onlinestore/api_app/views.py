from django.core.checks import messages
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from .serializers import CategorySerializer
from .serializers import ProductSerializer
from .models import Category
from .models import Product


# Category views.

class CategoryViews(APIView):
    
    def get(self, request, id=None):
        try:
            if id is None: #Category
                category = Category.objects.get(id=id)
                serializer = CategorySerializer(category)
                if serializer.is_valid():
                    return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
                else:
                    return Response("serializer.errors")
                # Collection of categories 
                categories = Category.objects.all()
                serializer = CategorySerializer(categories, many=True)
                if serializer.is_valid():
                    return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
                else:
                    return Response(serializer.errors)
        except Exception as e:
            return Response({"status": "error", "data": e.args}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        try:
            serializer = CategorySerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
            else:
                return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"status": "error", "data": e.args}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id=None):
        try:
            category = Category.objects.get(id=id)
            serializer = CategorySerializer(category, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
            else:
                return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"status": "error", "data": e.args}, status=status.HTTP_400_BAD_REQUEST)
        
    def delete(self, request, id=None):
        try:
            category = get_object_or_404(Category, id=id)
            category.delete()
            return Response({"status": "success", "data": "Item Deleted"})     
        except Exception as e:
            return Response({"status": "error", "data": e.args}, status=status.HTTP_400_BAD_REQUEST)
     
 
    # Product views.

class ProductViews(APIView):
    def get(self, request, id=None):
        try:
            if id: # Product
                product = Product.objects.get(id=id)
                serializer = ProductSerializer(product)
                if serializer.is_valid():
                    return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
                else:
                    return Response(serializer.errors)
                #Collection of products
                products = Product.objects.all()
                serializer = ProductSerializer(products, many=True)
                if serializer.is_valid():
                    return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
                else:
                    return Response(serializer.errors)
        except Exception as e:
            return Response({"status": "error", "data": e.args}, status=status.HTTP_400_BAD_REQUEST)
   
    def get(self, request, category_id=None):
        try:
            if id: # Collection of products by an category
                product = Product.objects.get(category_id=id)
                serializer = ProductSerializer(product)
                return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
            else:
                return Response({"status": "success", "data": {}}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"status": "error", "data": e.args}, status=status.HTTP_400_BAD_REQUEST)
   
    def post(self, request):
        try:
            serializer = ProductSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
            else:
                return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_400_BAD_REQUEST) 
        except Exception as e:
            return Response({"status": "error", "data": e.args}, status=status.HTTP_400_BAD_REQUEST)
        
    def patch(self, request, id=None,category_id=None):
        try:
            product = Product.objects.get(id=id,category_i=category_id)
            serializer = ProductSerializer(product, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
            else:
                return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"status": "error", "data": e.args}, status=status.HTTP_400_BAD_REQUEST)
                    
    def delete(self, request, id=None):
        try:
            product = get_object_or_404(Category, id=id)
            product.delete()
            return Response({"status": "success", "data": "Item Deleted"})    
        except Exception as e:
            return Response({"status": "error", "data": e.args}, status=status.HTTP_400_BAD_REQUEST)
                 