from rest_framework import serializers
from .models import Category
from .models import Product

class CategorySerializer(serializers.ModelSerializer):
    id=serializers.IntegerField(),
    name = serializers.CharField(max_length=200),
    description = serializers.CharField()
    
    class Meta:
        model = Category
        fields = ('__all__')
        
class ProductSerializer(serializers.ModelSerializer):
    id=serializers.IntegerField(),
    name = serializers.CharField(max_length=200),
    description = serializers.CharField(),
    manufactue_date = serializers.DateField()
    price = serializers.FloatField()
    category_id = serializers.IntegerField()
    
    class Meta:
        model = Product
        fields = ('__all__')        